package com.mixedpixel.socialflow;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_X_PHOTOS = 101;
    private static final int REQ_NOTIFICATIONS = 104;

    private SharedPreferences prefs;
    private LinearLayout body;
    private TextView accessStatus;
    private TextView folderStatus;
    private TextView latestStatus;
    private EditText creatorFilters;
    private EditText replyLines;
    private PendingIntent latestOriginalContentIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("socialflow", MODE_PRIVATE);
        requestNotificationPermissionIfNeeded();
        buildUi();
        handleLaunchIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleLaunchIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAccessStatus();
        refreshLatest();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247, 247, 249));

        TextView header = new TextView(this);
        header.setText("SocialFlow X Review");
        header.setTextSize(25);
        header.setTextColor(Color.BLACK);
        header.setPadding(dp(18), dp(18), dp(18), dp(4));
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("X notification watcher • local phrases • local photos");
        subtitle.setTextSize(13);
        subtitle.setTextColor(Color.DKGRAY);
        subtitle.setPadding(dp(18), 0, dp(18), dp(12));
        root.addView(subtitle);

        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(6), dp(16), dp(30));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        TextView intro = text("This X-only test watches Android notifications from the X app. When a notification matches one of your creator filters, it chooses a random reply phrase and a random photo and creates a review notification.");
        body.addView(intro);

        accessStatus = text("");
        accessStatus.setTextSize(17);
        body.addView(accessStatus);
        body.addView(button("Open Notification Access", v -> {
            try {
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            } catch (Exception e) {
                toast("Open Android Settings → Notifications → Notification access.");
            }
        }));

        body.addView(section("Creators to watch"));
        body.addView(text("Enter a handle or display-name fragment for each creator, one per line. SocialFlow only reacts when one of these appears in the X notification."));
        creatorFilters = edit(prefs.getString("x_creator_filters", ""), "@creator1\n@creator2", 5);
        creatorFilters.addTextChangedListener(saveWatcher("x_creator_filters"));
        body.addView(creatorFilters);

        body.addView(section("Random reply phrases"));
        body.addView(text("One phrase per line. A matching notification gets one randomly selected phrase."));
        replyLines = edit(prefs.getString("x_lines", "Nice one.\nInteresting point.\nWorth a look."), "One reply per line", 7);
        replyLines.addTextChangedListener(saveWatcher("x_lines"));
        body.addView(replyLines);

        body.addView(section("Random X photo folder"));
        folderStatus = text("");
        body.addView(folderStatus);
        body.addView(button("Choose X photo folder", v -> choosePhotoFolder()));
        refreshFolderStatus();

        body.addView(section("Latest detected creator post"));
        latestStatus = text("");
        latestStatus.setTextSize(16);
        body.addView(latestStatus);

        body.addView(button("Copy latest phrase", v -> copyLatestPhrase()));
        body.addView(button("Open exact X notification/post", v -> openOriginalXPost()));
        body.addView(button("Open selected photo", v -> openSelectedPhoto()));
        body.addView(button("Open X", v -> openXHome()));
        body.addView(button("Clear latest detected item", v -> {
            prefs.edit()
                    .remove("x_latest_title")
                    .remove("x_latest_text")
                    .remove("x_latest_draft")
                    .remove("x_latest_photo_uri")
                    .remove("x_latest_photo_name")
                    .apply();
            latestOriginalContentIntent = null;
            refreshLatest();
        }));

        TextView limitation = text("For this build, the final Reply/Post action and X account switching remain manual. The app does not silently send unsolicited replies or rotate through multiple accounts. Everything up to review can run from the X notification.");
        limitation.setTextColor(Color.rgb(120, 70, 0));
        limitation.setPadding(0, dp(16), 0, dp(8));
        body.addView(limitation);
    }

    private void handleLaunchIntent(Intent intent) {
        if (intent == null) return;
        if (intent.hasExtra("x_original_content_intent")) {
            if (Build.VERSION.SDK_INT >= 33) {
                latestOriginalContentIntent = intent.getParcelableExtra("x_original_content_intent", PendingIntent.class);
            } else {
                //noinspection deprecation
                latestOriginalContentIntent = intent.getParcelableExtra("x_original_content_intent");
            }
        }
        refreshLatest();
    }

    private void refreshLatest() {
        if (latestStatus == null) return;
        String title = prefs.getString("x_latest_title", "").trim();
        String text = prefs.getString("x_latest_text", "").trim();
        String draft = prefs.getString("x_latest_draft", "").trim();
        String photo = prefs.getString("x_latest_photo_name", "").trim();
        if (title.isEmpty() && text.isEmpty()) {
            latestStatus.setText("Nothing detected yet. Keep X post notifications enabled for your creators.");
            return;
        }
        StringBuilder s = new StringBuilder();
        if (!title.isEmpty()) s.append("X: ").append(title).append("\n");
        if (!text.isEmpty()) s.append(text).append("\n\n");
        s.append("Phrase: ").append(draft.isEmpty() ? "—" : draft).append("\n");
        s.append("Photo: ").append(photo.isEmpty() ? "No photo available" : photo);
        latestStatus.setText(s.toString());
    }

    private void refreshAccessStatus() {
        if (accessStatus == null) return;
        accessStatus.setText("X notification access: " + (hasNotificationListenerAccess() ? "ON ✓" : "OFF — tap below to enable"));
    }

    private boolean hasNotificationListenerAccess() {
        ComponentName cn = new ComponentName(this, XNotificationListenerService.class);
        if (Build.VERSION.SDK_INT >= 27) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.isNotificationListenerAccessGranted(cn);
        }
        String flat = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return flat != null && flat.contains(getPackageName());
    }

    private void choosePhotoFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(intent, REQ_X_PHOTOS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_X_PHOTOS && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) { }
            prefs.edit().putString("folder_x", uri.toString()).apply();
            refreshFolderStatus();
            toast("X photo folder saved.");
        }
    }

    private void refreshFolderStatus() {
        if (folderStatus == null) return;
        String uri = prefs.getString("folder_x", "");
        folderStatus.setText(uri.isEmpty() ? "Photo folder: not selected" : "Photo folder: selected ✓");
    }

    private void copyLatestPhrase() {
        String draft = prefs.getString("x_latest_draft", "").trim();
        if (draft.isEmpty()) {
            toast("No detected reply phrase yet.");
            return;
        }
        ClipboardManager cb = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("X reply", draft));
        toast("Reply phrase copied.");
    }

    private void openOriginalXPost() {
        if (latestOriginalContentIntent != null) {
            try {
                latestOriginalContentIntent.send();
                return;
            } catch (Exception ignored) { }
        }
        toast("Open the latest SocialFlow review notification to preserve the exact X post link.");
        openXHome();
    }

    private void openSelectedPhoto() {
        String raw = prefs.getString("x_latest_photo_uri", "");
        if (raw.isEmpty()) {
            toast("No photo was selected for the latest item.");
            return;
        }
        try {
            Uri uri = Uri.parse(raw);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, "image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            toast("Could not open that photo.");
        }
    }

    private void openXHome() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://x.com/home"));
            i.setPackage("com.twitter.android");
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://x.com/home")));
        }
    }

    private TextWatcher saveWatcher(String key) {
        return new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                prefs.edit().putString(key, s.toString()).apply();
            }
            @Override public void afterTextChanged(Editable s) { }
        };
    }

    private TextView section(String s) {
        TextView t = text(s);
        t.setTextSize(20);
        t.setTextColor(Color.BLACK);
        t.setPadding(0, dp(18), 0, dp(6));
        return t;
    }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(15);
        t.setTextColor(Color.rgb(50, 50, 55));
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private Button button(String label, android.view.View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        p.setMargins(0, dp(5), 0, dp(5));
        b.setLayoutParams(p);
        return b;
    }

    private EditText edit(String value, String hint, int minLines) {
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setHint(hint);
        e.setTextSize(15);
        e.setMinLines(minLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private int dp(int n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
