package com.mixedpixel.socialflow;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class XNotificationListenerService extends NotificationListenerService {
    private static final String CHANNEL_ID = "x_creator_review";
    private static final int BASE_NOTIFICATION_ID = 4300;
    private final Random random = new Random();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        String pkg = sbn.getPackageName();
        if (!"com.twitter.android".equals(pkg) && !"com.twitter.android.lite".equals(pkg)) return;

        Notification n = sbn.getNotification();
        if (n == null) return;
        Bundle extras = n.extras;
        String title = value(extras, Notification.EXTRA_TITLE);
        String text = firstNonEmpty(
                value(extras, Notification.EXTRA_BIG_TEXT),
                value(extras, Notification.EXTRA_TEXT),
                value(extras, Notification.EXTRA_SUB_TEXT)
        );
        String combined = (title + " " + text).trim();
        if (combined.isEmpty()) return;

        SharedPreferences prefs = getSharedPreferences("socialflow", MODE_PRIVATE);
        List<String> creators = lines(prefs.getString("x_creator_filters", ""));
        if (creators.isEmpty() || !matchesCreator(combined, creators)) return;
        if (looksLikeNonPostNotification(combined)) return;

        String fingerprint = sbn.getKey() + "|" + combined;
        String last = prefs.getString("x_last_fingerprint", "");
        long lastAt = prefs.getLong("x_last_fingerprint_at", 0L);
        long now = System.currentTimeMillis();
        if (fingerprint.equals(last) && now - lastAt < 120_000L) return;

        List<String> replies = lines(prefs.getString("x_lines", ""));
        if (replies.isEmpty()) return;
        String draft = replies.get(random.nextInt(replies.size()));
        PhotoPick photo = chooseRandomPhoto(prefs.getString("folder_x", ""));

        prefs.edit()
                .putString("x_last_fingerprint", fingerprint)
                .putLong("x_last_fingerprint_at", now)
                .putString("x_latest_title", title)
                .putString("x_latest_text", text)
                .putString("x_latest_draft", draft)
                .putString("x_latest_photo_uri", photo == null ? "" : photo.uri.toString())
                .putString("x_latest_photo_name", photo == null ? "" : photo.name)
                .putLong("x_latest_at", now)
                .apply();

        postReviewNotification(title, text, draft, photo, n.contentIntent, now);
    }

    private void postReviewNotification(String title, String text, String draft, PhotoPick photo,
                                        PendingIntent originalContentIntent, long now) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "X creator post reviews",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Detected X creator-post notifications waiting for review");
            nm.createNotificationChannel(channel);
        }

        Intent review = new Intent(this, MainActivity.class);
        review.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        review.putExtra("x_title", title);
        review.putExtra("x_text", text);
        review.putExtra("x_draft", draft);
        if (photo != null) {
            review.putExtra("x_photo_uri", photo.uri.toString());
            review.putExtra("x_photo_name", photo.name);
        }
        if (originalContentIntent != null) review.putExtra("x_original_content_intent", originalContentIntent);

        int requestCode = (int) (now & 0x7fffffff);
        PendingIntent reviewPending = PendingIntent.getActivity(
                this,
                requestCode,
                review,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String body = "Phrase: " + draft;
        if (photo != null) body += "\nPhoto: " + photo.name;

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title.isEmpty() ? "X creator post detected" : title)
                .setContentText("Reply prepared — tap to review")
                .setStyle(new Notification.BigTextStyle().bigText(text + "\n\n" + body))
                .setContentIntent(reviewPending)
                .setAutoCancel(true)
                .setPriority(Notification.PRIORITY_HIGH);

        if (originalContentIntent != null) {
            // This action opens the exact destination carried by the original X notification.
            // The final Reply/Post remains a user action inside X.
            builder.addAction(new Notification.Action.Builder(
                    android.R.drawable.ic_menu_view,
                    "Open X post",
                    originalContentIntent
            ).build());
        }

        nm.notify(BASE_NOTIFICATION_ID + requestCode % 1000, builder.build());
    }

    private boolean matchesCreator(String combined, List<String> creators) {
        String hay = normalize(combined);
        for (String creator : creators) {
            String needle = normalize(creator);
            if (needle.startsWith("@")) needle = needle.substring(1);
            if (!needle.isEmpty() && hay.contains(needle)) return true;
        }
        return false;
    }

    private boolean looksLikeNonPostNotification(String combined) {
        String s = combined.toLowerCase(Locale.ROOT);
        String[] blocked = new String[]{
                "liked your", "followed you", "replied to you", "mentioned you",
                "sent you", "direct message", "message from", "reposted your",
                "joined x", "spaces", "space is live", "recommended for you",
                "trending", "what's happening", "people you may know"
        };
        for (String b : blocked) if (s.contains(b)) return true;
        return false;
    }

    private String normalize(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replace("@", "").trim();
    }

    private String value(Bundle extras, String key) {
        if (extras == null) return "";
        CharSequence cs = extras.getCharSequence(key);
        return cs == null ? "" : cs.toString().trim();
    }

    private String firstNonEmpty(String... values) {
        for (String v : values) if (v != null && !v.trim().isEmpty()) return v.trim();
        return "";
    }

    private List<String> lines(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        for (String part : raw.split("\\r?\\n")) {
            String s = part.trim();
            if (!s.isEmpty()) out.add(s);
        }
        return out;
    }

    private PhotoPick chooseRandomPhoto(String treeRaw) {
        if (treeRaw == null || treeRaw.trim().isEmpty()) return null;
        try {
            Uri treeUri = Uri.parse(treeRaw);
            String parentDocumentId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId);
            String[] projection = new String[]{
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
            };
            List<PhotoPick> images = new ArrayList<>();
            try (Cursor c = getContentResolver().query(childrenUri, projection, null, null, null)) {
                if (c != null) {
                    int idCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                    int nameCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                    int mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                    while (c.moveToNext()) {
                        String documentId = idCol >= 0 ? c.getString(idCol) : null;
                        String name = nameCol >= 0 ? c.getString(nameCol) : "photo";
                        String mime = mimeCol >= 0 ? c.getString(mimeCol) : "";
                        if (documentId == null || mime == null || !mime.startsWith("image/")) continue;
                        Uri documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId);
                        images.add(new PhotoPick(documentUri, name == null ? "photo" : name));
                    }
                }
            }
            if (images.isEmpty()) return null;
            return images.get(random.nextInt(images.size()));
        } catch (Exception e) {
            return null;
        }
    }

    private static class PhotoPick {
        final Uri uri;
        final String name;
        PhotoPick(Uri uri, String name) {
            this.uri = uri;
            this.name = name;
        }
    }
}
