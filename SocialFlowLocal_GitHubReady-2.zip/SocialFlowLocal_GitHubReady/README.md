# SocialFlow X Review — v0.2

This is an X-only test build focused on Android notification detection.

## What it does

- Uses Android Notification Access to watch notifications from the installed X app.
- Matches notifications against creator handles/display-name fragments you configure.
- Picks one random reply phrase from your local phrase list.
- Picks one random image from a local folder selected through Android's Storage Access Framework.
- Creates a SocialFlow review notification showing the prepared phrase/photo.
- Preserves the original X notification's destination while the review notification is active, so the exact X post can be opened.
- Keeps creator filters, reply phrases, selected folder, and recent detection history locally on the phone.

## What it intentionally does not do

The final Reply/Post action and X account switching remain manual. This build does not silently send unsolicited replies or rotate across multiple X accounts.

## First setup

1. Install the APK.
2. Open SocialFlow X Review.
3. Tap **Open Notification Access** and enable SocialFlow.
4. Enter creator handles or display-name fragments, one per line.
5. Enter random reply phrases, one per line.
6. Choose the local X photo folder.
7. In X, enable post notifications for those creators.
8. When a matching X notification arrives, SocialFlow will create a review notification.

## Building

The existing GitHub Actions workflow used for the first SocialFlow build can compile this project with Android API 35 and Gradle.
