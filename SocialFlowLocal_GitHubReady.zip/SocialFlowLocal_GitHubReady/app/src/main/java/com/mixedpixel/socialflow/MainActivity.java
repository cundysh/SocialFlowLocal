package com.mixedpixel.socialflow;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_X_PHOTOS = 101;
    private static final int REQ_TIKTOK = 102;
    private static final int REQ_INSTAGRAM = 103;
    private static final int REQ_NOTIFICATIONS = 104;

    private final Random random = new Random();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private LinearLayout root;
    private LinearLayout body;
    private TextView status;
    private int pendingFolderRequest = 0;

    private EditText xLines;
    private EditText xHandles;
    private EditText xPostUrl;
    private TextView xDraft;
    private EditText igAccounts;
    private EditText igCurrentAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("socialflow", MODE_PRIVATE);
        requestNotificationPermissionIfNeeded();
        buildShell();
        showDashboard();
    }

    private void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247,247,249));

        TextView header = new TextView(this);
        header.setText("SocialFlow Local");
        header.setTextSize(24);
        header.setTextColor(Color.BLACK);
        header.setPadding(dp(18), dp(18), dp(18), dp(10));
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(this);
        status.setTextSize(13);
        status.setTextColor(Color.DKGRAY);
        status.setPadding(dp(18), 0, dp(18), dp(10));
        root.addView(status);

        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(8), dp(4), dp(8), dp(8));
        addNav(nav, "Home", v -> showDashboard());
        addNav(nav, "X", v -> showX());
        addNav(nav, "TikTok", v -> showTikTok());
        addNav(nav, "Instagram", v -> showInstagram());
        root.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView scroll = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(8), dp(16), dp(24));
        scroll.addView(body);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private void addNav(LinearLayout nav, String label, View.OnClickListener click) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1f);
        p.setMargins(dp(3),0,dp(3),0);
        nav.addView(b,p);
    }

    private void clearBody(String title) {
        body.removeAllViews();
        TextView h = new TextView(this);
        h.setText(title);
        h.setTextSize(22);
        h.setTextColor(Color.BLACK);
        h.setPadding(0, dp(6), 0, dp(10));
        body.addView(h);
        refreshStatus();
    }

    private void refreshStatus() {
        status.setText("Local media • Local history • No SocialFlow server");
    }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(15);
        t.setTextColor(Color.rgb(50,50,55));
        t.setPadding(0,dp(5),0,dp(5));
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        p.setMargins(0,dp(5),0,dp(5));
        b.setLayoutParams(p);
        return b;
    }

    private EditText edit(String value, String hint, int minLines) {
        EditText e = new EditText(this);
        e.setText(value == null ? "" : value);
        e.setHint(hint);
        e.setTextSize(15);
        e.setMinLines(minLines);
        e.setGravity(Gravity.TOP | Gravity.START);
        e.setPadding(dp(12),dp(10),dp(12),dp(10));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0,dp(4),0,dp(8));
        e.setLayoutParams(p);
        return e;
    }

    private void showDashboard() {
        saveVisibleEditors();
        clearBody("Dashboard");
        body.addView(text("This first test build keeps your videos, photos, account labels, reply lines and used-media history on the phone."));
        body.addView(text("X: draft a reply from your saved lines, then approve or skip.\nTikTok: share the next unused video only when Android reports a VPN and the public IP check reports US.\nInstagram: track reels per account and prepare the next unused reel."));

        body.addView(button("Open X workflow", v -> showX()));
        body.addView(button("Open TikTok workflow", v -> showTikTok()));
        body.addView(button("Open Instagram workflow", v -> showInstagram()));
        body.addView(button("Schedule sample reminders", v -> scheduleSampleReminders()));
        body.addView(button("Reset used-media history", v -> {
            Set<String> keys = new HashSet<>(prefs.getAll().keySet());
            SharedPreferences.Editor ed = prefs.edit();
            for (String k : keys) if (k.startsWith("used_")) ed.remove(k);
            ed.apply();
            toast("Used-media history cleared.");
        }));

        TextView caveat = text("Test-build limitation: this version does not store social passwords and does not silently press Post inside X, TikTok or Instagram. It prepares the media/reply and hands it to the installed app. Direct API posting can be wired in later after the platform developer credentials are available.");
        caveat.setTextColor(Color.rgb(120,70,0));
        body.addView(caveat);
    }

    private void showX() {
        saveVisibleEditors();
        clearBody("X — reply assistant");
        body.addView(text("Put one reply phrase on each line. The app chooses one randomly. Add creator handles here as your own watch list for the later API-connected version."));

        xHandles = edit(prefs.getString("x_handles", ""), "Creator handles, one per line", 3);
        body.addView(xHandles);
        xLines = edit(prefs.getString("x_lines", "Nice one.\nInteresting point.\nThat is worth thinking about."), "Reply lines, one per line", 6);
        body.addView(xLines);
        xPostUrl = edit(prefs.getString("x_post_url", ""), "Paste the X post URL for this test", 1);
        body.addView(xPostUrl);

        body.addView(button(folderLabel("X photos", "folder_x"), v -> pickFolder(REQ_X_PHOTOS)));
        xDraft = text("Draft: " + prefs.getString("x_current_draft", "—"));
        xDraft.setTextSize(18);
        xDraft.setPadding(dp(10),dp(12),dp(10),dp(12));
        body.addView(xDraft);

        body.addView(button("Generate random draft", v -> generateXDraft()));
        body.addView(button("Approve — copy reply & open X post", v -> approveX()));
        body.addView(button("Skip draft", v -> {
            prefs.edit().remove("x_current_draft").apply();
            xDraft.setText("Draft: —");
        }));
        body.addView(text("Daily target stored for this project: up to 100 approved replies per 24 hours. This test build keeps approval manual."));
    }

    private void generateXDraft() {
        saveVisibleEditors();
        List<String> lines = nonEmptyLines(prefs.getString("x_lines", ""));
        if (lines.isEmpty()) { toast("Add at least one reply line."); return; }
        String draft = lines.get(random.nextInt(lines.size()));
        prefs.edit().putString("x_current_draft", draft).apply();
        xDraft.setText("Draft: " + draft);
    }

    private void approveX() {
        saveVisibleEditors();
        String draft = prefs.getString("x_current_draft", "").trim();
        if (draft.isEmpty()) { generateXDraft(); draft = prefs.getString("x_current_draft", "").trim(); }
        if (draft.isEmpty()) return;
        ClipboardManager cb = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        cb.setPrimaryClip(ClipData.newPlainText("X reply", draft));
        String url = prefs.getString("x_post_url", "").trim();
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url.isEmpty() ? "https://x.com/home" : url));
            i.setPackage("com.twitter.android");
            startActivity(i);
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url.isEmpty() ? "https://x.com/home" : url)));
        }
        incrementDaily("x_approved");
        toast("Reply copied. Paste it into the reply box.");
    }

    private void showTikTok() {
        saveVisibleEditors();
        clearBody("TikTok — local videos");
        body.addView(text("Rule: maximum 2 per day, video only — no caption, hashtags, music or edits. TikTok actions are blocked unless a VPN is active. The US-IP check uses a public country lookup; SocialFlow does not run a server."));
        body.addView(button(folderLabel("TikTok videos", "folder_tiktok"), v -> pickFolder(REQ_TIKTOK)));
        body.addView(text("VPN status: " + (isVpnActive() ? "ACTIVE" : "NOT ACTIVE")));
        body.addView(button("Check VPN + US public IP", v -> checkUsIp()));
        body.addView(button("Share next unused video to TikTok", v -> postTikTokNext()));
        body.addView(button("Schedule 2 random TikTok reminders today", v -> scheduleRandomToday("TikTok due", "Open SocialFlow. Posting will only continue if VPN + US IP pass.", 2)));
        body.addView(text("Posted/share count today: " + getDailyCount("tiktok_posts") + " / 2"));
    }

    private void checkUsIp() {
        if (!isVpnActive()) { toast("VPN is not active. TikTok stays paused."); return; }
        toast("Checking public IP country…");
        executor.execute(() -> {
            boolean us = false;
            String result = "Could not verify";
            try {
                URL url = new URL("https://api.country.is/");
                HttpURLConnection c = (HttpURLConnection) url.openConnection();
                c.setConnectTimeout(7000);
                c.setReadTimeout(7000);
                c.setRequestProperty("User-Agent", "SocialFlowLocal/0.1");
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                String s = sb.toString().replace(" ", "");
                us = s.contains("\"country\":\"US\"");
                result = us ? "US IP confirmed" : "Public IP is not reported as US";
            } catch (Exception e) {
                result = "IP check failed: " + e.getClass().getSimpleName();
            }
            final boolean finalUs = us;
            final String finalResult = result;
            runOnUiThread(() -> {
                prefs.edit().putBoolean("tiktok_us_ok", finalUs).putLong("tiktok_us_checked", System.currentTimeMillis()).apply();
                toast(finalResult);
                showTikTok();
            });
        });
    }

    private void postTikTokNext() {
        if (!isVpnActive()) { toast("VPN is off. TikTok skipped."); return; }
        if (!recentUsCheck()) { toast("Run 'Check VPN + US public IP' first."); return; }
        if (getDailyCount("tiktok_posts") >= 2) { toast("TikTok daily maximum reached."); return; }
        Uri folder = storedFolder("folder_tiktok");
        if (folder == null) { toast("Choose the TikTok folder first."); return; }
        MediaItem item = chooseUnused(folder, "video/", "used_tiktok");
        if (item == null) { toast("No unused videos found."); return; }
        if (shareMedia(item.uri, item.mime, "com.zhiliaoapp.musically")) {
            markUsed("used_tiktok", item.id);
            incrementDaily("tiktok_posts");
        }
    }

    private boolean recentUsCheck() {
        boolean ok = prefs.getBoolean("tiktok_us_ok", false);
        long at = prefs.getLong("tiktok_us_checked", 0L);
        return ok && System.currentTimeMillis() - at < 30L * 60L * 1000L;
    }

    private void showInstagram() {
        saveVisibleEditors();
        clearBody("Instagram — reels queue");
        body.addView(text("You set up each Instagram account yourself first (profile, bio link, story/highlight). SocialFlow then tracks local reel usage per account."));

        igAccounts = edit(prefs.getString("ig_accounts", ""), "Account labels, one per line", 4);
        body.addView(igAccounts);
        igCurrentAccount = edit(prefs.getString("ig_current", ""), "Current account label, e.g. account_01", 1);
        body.addView(igCurrentAccount);
        body.addView(button(folderLabel("Instagram reels", "folder_instagram"), v -> pickFolder(REQ_INSTAGRAM)));
        body.addView(button("Prepare/share next unused reel", v -> postInstagramNext()));
        body.addView(button("Start first-day batch (15 reminders / ~10 min)", v -> scheduleInstagramFirstDay()));
        body.addView(button("Schedule daily random 1–3 reel reminders", v -> scheduleInstagramDaily()));
        body.addView(button("Mark current account verification-blocked", v -> disableCurrentInstagram()));
        body.addView(text("A verification-blocked account is disabled locally and excluded from future scheduling. SocialFlow does not attempt to bypass checkpoints."));
    }

    private void postInstagramNext() {
        saveVisibleEditors();
        String acct = prefs.getString("ig_current", "").trim();
        if (acct.isEmpty()) { toast("Enter the current account label."); return; }
        if (prefs.getBoolean("ig_disabled_" + acct, false)) { toast("This account is disabled due to verification/checkpoint status."); return; }
        Uri folder = storedFolder("folder_instagram");
        if (folder == null) { toast("Choose the Instagram reels folder first."); return; }
        MediaItem item = chooseUnused(folder, "video/", "used_ig_" + safeKey(acct));
        if (item == null) { toast("No unused reels found for " + acct + "."); return; }
        if (shareMedia(item.uri, item.mime, "com.instagram.android")) {
            markUsed("used_ig_" + safeKey(acct), item.id);
        }
    }

    private void scheduleInstagramFirstDay() {
        saveVisibleEditors();
        String acct = prefs.getString("ig_current", "").trim();
        if (acct.isEmpty()) { toast("Enter the current account label."); return; }
        if (prefs.getBoolean("ig_disabled_" + acct, false)) { toast("Account is disabled."); return; }
        long now = System.currentTimeMillis();
        for (int i=0;i<15;i++) {
            scheduleAlarm(now + (i * 40_000L), "Instagram first-day batch", acct + ": reel " + (i+1) + " of 15 is ready.", 3000 + i);
        }
        toast("15 reminders scheduled across about 10 minutes for " + acct + ".");
    }

    private void scheduleInstagramDaily() {
        saveVisibleEditors();
        String acct = prefs.getString("ig_current", "").trim();
        if (acct.isEmpty()) { toast("Enter the current account label."); return; }
        if (prefs.getBoolean("ig_disabled_" + acct, false)) { toast("Account is disabled."); return; }
        int n = 1 + random.nextInt(3);
        scheduleRandomToday("Instagram reel due", acct + ": open SocialFlow for the next unused reel.", n);
        toast(n + " random reminder(s) scheduled today for " + acct + ".");
    }

    private void disableCurrentInstagram() {
        saveVisibleEditors();
        String acct = prefs.getString("ig_current", "").trim();
        if (acct.isEmpty()) { toast("Enter the account label."); return; }
        prefs.edit().putBoolean("ig_disabled_" + acct, true).apply();
        toast(acct + " disabled locally.");
    }

    private void saveVisibleEditors() {
        SharedPreferences.Editor ed = prefs.edit();
        if (xLines != null) ed.putString("x_lines", xLines.getText().toString());
        if (xHandles != null) ed.putString("x_handles", xHandles.getText().toString());
        if (xPostUrl != null) ed.putString("x_post_url", xPostUrl.getText().toString());
        if (igAccounts != null) ed.putString("ig_accounts", igAccounts.getText().toString());
        if (igCurrentAccount != null) ed.putString("ig_current", igCurrentAccount.getText().toString());
        ed.apply();
        xLines = null; xHandles = null; xPostUrl = null; igAccounts = null; igCurrentAccount = null;
    }

    private void pickFolder(int requestCode) {
        pendingFolderRequest = requestCode;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        String key = requestCode == REQ_X_PHOTOS ? "folder_x" : requestCode == REQ_TIKTOK ? "folder_tiktok" : "folder_instagram";
        prefs.edit().putString(key, uri.toString()).apply();
        toast("Folder saved.");
        if (requestCode == REQ_X_PHOTOS) showX(); else if (requestCode == REQ_TIKTOK) showTikTok(); else showInstagram();
    }

    private String folderLabel(String title, String key) {
        return title + ": " + (prefs.contains(key) ? "selected ✓" : "choose folder");
    }

    private Uri storedFolder(String key) {
        String s = prefs.getString(key, "");
        return s.isEmpty() ? null : Uri.parse(s);
    }

    private static class MediaItem {
        Uri uri; String mime; String name; String id;
        MediaItem(Uri u, String m, String n, String i) { uri=u; mime=m; name=n; id=i; }
    }

    private MediaItem chooseUnused(Uri treeUri, String mimePrefix, String usedKey) {
        List<MediaItem> all = listFiles(treeUri, mimePrefix);
        if (all.isEmpty()) return null;
        Set<String> used = new HashSet<>(prefs.getStringSet(usedKey, Collections.emptySet()));
        List<MediaItem> available = new ArrayList<>();
        for (MediaItem m : all) if (!used.contains(m.id)) available.add(m);
        if (available.isEmpty()) return null;
        return available.get(random.nextInt(available.size()));
    }

    private List<MediaItem> listFiles(Uri treeUri, String mimePrefix) {
        List<MediaItem> out = new ArrayList<>();
        try {
            String treeDocId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId);
            String[] projection = {DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE};
            try (Cursor c = getContentResolver().query(children, projection, null, null, null)) {
                if (c != null) while (c.moveToNext()) {
                    String docId = c.getString(0);
                    String name = c.getString(1);
                    String mime = c.getString(2);
                    if (mime != null && mime.startsWith(mimePrefix)) {
                        Uri doc = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                        out.add(new MediaItem(doc, mime, name, docId + "|" + name));
                    }
                }
            }
        } catch (Exception e) {
            toast("Could not read folder: " + e.getClass().getSimpleName());
        }
        return out;
    }

    private void markUsed(String key, String id) {
        Set<String> s = new HashSet<>(prefs.getStringSet(key, Collections.emptySet()));
        s.add(id);
        prefs.edit().putStringSet(key, s).apply();
    }

    private boolean shareMedia(Uri uri, String mime, String packageName) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mime == null ? "video/*" : mime);
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            send.setPackage(packageName);
            startActivity(send);
            return true;
        } catch (Exception e) {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(mime == null ? "video/*" : mime);
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send, "Share media"));
                return true;
            } catch (Exception e2) {
                toast("No compatible app found.");
                return false;
            }
        }
    }

    private boolean isVpnActive() {
        try {
            ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
            for (Network network : cm.getAllNetworks()) {
                NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private List<String> nonEmptyLines(String s) {
        List<String> out = new ArrayList<>();
        if (s == null) return out;
        for (String line : s.split("\\r?\\n")) if (!line.trim().isEmpty()) out.add(line.trim());
        return out;
    }

    private String safeKey(String s) { return s.replaceAll("[^A-Za-z0-9_.-]", "_"); }

    private String todayKey() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }
    private int getDailyCount(String name) { return prefs.getInt(name + "_" + todayKey(), 0); }
    private void incrementDaily(String name) {
        String k = name + "_" + todayKey();
        prefs.edit().putInt(k, prefs.getInt(k,0)+1).apply();
    }

    private void scheduleRandomToday(String title, String msg, int count) {
        Calendar now = Calendar.getInstance();
        long start = System.currentTimeMillis() + 60_000L;
        Calendar end = Calendar.getInstance();
        end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 30); end.set(Calendar.SECOND, 0);
        long stop = Math.max(start + 60_000L, end.getTimeInMillis());
        for (int i=0;i<count;i++) {
            long when = start + (long)(random.nextDouble() * Math.max(1L, stop - start));
            scheduleAlarm(when, title, msg, 5000 + random.nextInt(1000000));
        }
        toast(count + " reminder(s) scheduled for today.");
    }

    private void scheduleSampleReminders() {
        long now = System.currentTimeMillis();
        scheduleAlarm(now + 60_000L, "X draft", "A reply can be reviewed in SocialFlow.", 9101);
        scheduleAlarm(now + 120_000L, "TikTok check", "TikTok action is due; VPN + US IP will be checked first.", 9102);
        scheduleAlarm(now + 180_000L, "Instagram reel", "Your next local reel is ready.", 9103);
        toast("Sample reminders scheduled for 1, 2 and 3 minutes from now.");
    }

    private void scheduleAlarm(long when, String title, String msg, int id) {
        Intent i = new Intent(this, ReminderReceiver.class);
        i.putExtra("title", title); i.putExtra("text", msg); i.putExtra("id", id);
        PendingIntent pi = PendingIntent.getBroadcast(this, id, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, when, pi);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    protected void onPause() {
        saveVisibleEditors();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
