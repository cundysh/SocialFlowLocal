# SocialFlow Local — Project Notes

Priority order: Instagram first, then TikTok, then X.

## Local-first requirement
- No SocialFlow-owned server for the user's media library.
- Videos/photos remain in folders on the Android phone.
- User can add/delete/replace files at any time.
- App only reads the chosen folders and stores lightweight local history/settings.

## X
- User manually chooses large creator accounts to follow/watch.
- New-post workflow should create a suggested reply and notify the phone.
- User chooses Post/Approve or Skip.
- Daily cap/target: 100 approved replies in 24h.
- Replies come from editable text lines.
- Optional random photo comes from chosen local photo folder.
- Do not build a mode intended to disguise automation as a human user.

## TikTok
- Maximum 2 videos per day.
- Video exactly as stored: no caption, hashtags, music or edits.
- Read videos from chosen local folder.
- Before a TikTok action: require VPN active.
- Also verify public IP is US; otherwise skip TikTok and continue other workflows.

## Instagram
- User manually creates/configures each account first, including bio link and story/highlight.
- App handles reels after account setup.
- User may create/connect 3–5 accounts per day.
- Media pool can contain ~30–100+ reels.
- First day on a new account: 15 reels in a batch target of about 10 minutes.
- Later days: random 1–3 reels per day at random times.
- Keep used-reel history per account to avoid immediate repeats.
- If an account requires human verification/checkpoint, stop using it and disable it from future runs. Do not bypass verification.
