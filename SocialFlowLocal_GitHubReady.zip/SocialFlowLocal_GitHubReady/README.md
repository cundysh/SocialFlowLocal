# SocialFlow Local — Android prototype v0.1

This is a local-first Android project for the workflow discussed in chat.

## What is implemented

- One Android app with Home, X, TikTok and Instagram sections.
- Local folder access through Android's Storage Access Framework. The app does not rename, delete or edit your media files.
- Local used-media history so a selected account does not immediately reuse the same reel/video.
- X reply-line editor. One phrase per line; the app picks a random line for a draft.
- X manual approval flow: copy the selected reply and open the X post URL.
- TikTok video selection from a phone folder, maximum 2 actions per day.
- TikTok VPN check using Android network capabilities.
- Optional US public-IP country check using `https://api.country.is/`; no SocialFlow server is used.
- TikTok is blocked in the app when VPN is not active or the recent US country check did not pass.
- Instagram account labels and separate used-reel history per account.
- Instagram first-day batch reminders: 15 reminders over roughly 10 minutes.
- Instagram daily scheduling: random 1–3 reminders for the selected account.
- Verification/checkpoint handling: an account can be marked disabled; the app will stop scheduling/sharing for it.
- Android notifications/alarms for scheduled actions.

## Important test-build limitation

This project intentionally does **not** store your X/TikTok/Instagram passwords and it does not use accessibility tricks to imitate taps inside those apps. In v0.1, the final social-network action is handed to the installed X/TikTok/Instagram app.

Fully direct posting/watch functionality requires each platform's supported developer/API connection and credentials. Those credentials are not included in this file, so the prototype does not pretend that direct API posting is already connected.

## Project rules saved in the prototype

### X
- You choose the creator accounts yourself.
- Target: up to 100 approved replies per 24 hours.
- Reply phrases are editable, one per line.
- Photo folder is selectable locally.
- Reply remains user-approved before posting.

### TikTok
- Videos are read from a local phone folder.
- Video is sent as-is: no caption, hashtags, music or edits added by SocialFlow.
- Maximum 2 per day.
- If VPN is off, TikTok is paused.
- The app can verify that the public IP is reported as US before allowing the TikTok share action.

### Instagram
- You manually set up each account first (bio/profile/story/highlight/link).
- Reels come from one local phone folder.
- First day for a new account: 15-item batch reminder queue.
- After first day: random 1, 2 or 3 reel reminders per day.
- Used reels are tracked separately for each account label.
- If an account reaches a verification/checkpoint state, mark it disabled and it is excluded from future actions.

## Open/build

1. Open the `SocialFlowLocal` folder in Android Studio.
2. Let Android Studio install/sync Android SDK 35 and Gradle dependencies.
3. Run the `app` configuration on an Android phone (Android 8.0+).
4. Grant notification permission.
5. In each platform tab, choose the local media folder.

The project uses only standard Android APIs in the application code; no third-party runtime library is required.

## Next build milestone

To turn v0.1 into a direct API-connected version, add supported authentication/publishing modules for the platforms and keep tokens in Android Keystore. X monitoring/posting, TikTok direct posting, and Instagram account-specific direct posting should only be enabled after those platform credentials and permissions are available.

## Build APK with GitHub Actions

The repository includes `.github/workflows/android-build.yml`. Every push to `main` builds a debug APK. Open **Actions** -> **Build Android APK** -> latest successful run -> **Artifacts** -> `SocialFlowLocal-debug-apk`.
